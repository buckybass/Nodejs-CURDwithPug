module.exports=(req, res) => {
  res.render('users-create')
}
